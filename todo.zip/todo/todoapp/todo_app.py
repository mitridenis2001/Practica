import tkinter as tk
class ToDoApp:
    def __init__(self, manager):
        self.manager = manager

        self.window = tk.Tk()
        self.window.title("To-Do List")
        self.window.geometry("400x300")

        self.listbox_tasks = tk.Listbox(self.window, width=50, font=("Arial", 12))
        self.listbox_tasks.pack(pady=10)

        self.populate_tasks()

        self.entry_task = tk.Entry(self.window, width=50, font=("Arial", 12))
        self.entry_task.pack(pady=5)

        frame_buttons = tk.Frame(self.window)
        frame_buttons.pack(pady=5)

        button_add = tk.Button(frame_buttons, text="Add Task", command=self.add_task, font=("Arial", 12), bg="lightgreen", fg="white")
        button_add.grid(row=0, column=0, padx=5)

        button_remove = tk.Button(frame_buttons, text="Remove Task", command=self.remove_task, font=("Arial", 12), bg="tomato", fg="white")
        button_remove.grid(row=0, column=1, padx=5)

        button_toggle = tk.Button(frame_buttons, text="Toggle Completed", command=self.toggle_task, font=("Arial", 12), bg="skyblue", fg="white")
        button_toggle.grid(row=0, column=2, padx=5)

        self.window.mainloop()

    def populate_tasks(self):
        for task in self.manager.tasks:
            self.listbox_tasks.insert(tk.END, task['title'])
            if task['completed']:
                self.listbox_tasks.itemconfig(tk.END, foreground='green')

    def add_task(self):
        if len(self.entry_task.get()) > 0:
            task = {
                'title': self.entry_task.get(),
                'completed': False
            }
            self.manager.add_task(task)
            self.listbox_tasks.insert(tk.END, task['title'])
            self.entry_task.delete(0, tk.END)

    def remove_task(self):
        selected_task = self.listbox_tasks.curselection()
        if selected_task:
            index = selected_task[0]
            self.manager.remove_task(index)
            self.listbox_tasks.delete(selected_task)

    def toggle_task(self):
        selected_task = self.listbox_tasks.curselection()
        if selected_task:
            index = selected_task[0]
            self.manager.toggle_task(index)
            task = self.manager.tasks[index]
            self.listbox_tasks.itemconfig(selected_task, foreground='green' if task['completed'] else 'black')
